==============================================
Top Free Corporate WordPress Theme
==============================================
Theme Name      :   Zyloplus
Theme URI         :   http://zylothemes.com/themes/top-free-corporate-wordpress-theme/
Version                :   1.6.4
Tested up to        :   WP 4.7.3
Author                  :   Zylo Themes
Author URI           :   http://www.zylothemes.com/
license                  :   GNU General Public License v3.0
License URI         :   http://www.gnu.org/licenses/gpl.html

==========================================================
Zyloplus WordPress Theme bundles the following third-party resources:
==========================================================
Theme is Built using the following resource bundles.
All js that have been used are within folder /js of theme.
jQuery Nivo Slider
Copyright 2012, Dev7studios, under MIT license
http://nivo.dev7studios.com
Montserrat :https://www.google.com/fonts/specimen/Montserrat
License: Distributed under the terms of the Apache License, version 2.0 		
http://www.apache.org/licenses/LICENSE-2.0.html
 Images used from Pixabay.
Pixabay provides images under CC0 license 
(https://creativecommons.org/about/cc0)
Slider Images:	
https://pixabay.com/en/backcountry-skiiing-morning-885854/	
Font-Awesome
Font Awesome 4.5.0 by @davegandy - http://fontawesome.io - @fontawesome
License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
For any help you can mail us at zylothemes@gmail.com

==============================================
Theme copyright/license attribution
==============================================

Zyloplus Theme is derived from Businessweb Plus, Copyright Grace Themes(gracethemes.com), 2016.
Businessweb Plus WordPress Theme is released under the terms of GNU GPL